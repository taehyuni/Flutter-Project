import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  final bool isDarkMode;
  final Function(bool) onThemeChanged;
  final double fontSize;
  final Function(double) onFontSizeChanged;
  final VoidCallback onResetData;
  final int goalExpense;
  final Function(int) onGoalExpenseChanged;

  const SettingsPage({
    Key? key,
    required this.isDarkMode,
    required this.onThemeChanged,
    required this.fontSize,
    required this.onFontSizeChanged,
    required this.goalExpense,
    required this.onGoalExpenseChanged,
    required this.onResetData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool notificationsEnabled = true;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '설정',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 16, bottom: 8),
            child: Text(
              '글자 크기 조절',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Slider(
            value: fontSize,
            min: 12,
            max: 24,
            divisions: 6,
            label: '${fontSize.toInt()} pt',
            onChanged: onFontSizeChanged,
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              '예시 텍스트: 예시 텍스트 입니다',
              style: TextStyle(fontSize: fontSize),
            ),
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('다크 모드'),
            value: isDarkMode,
            onChanged: onThemeChanged,
            secondary: const Icon(Icons.dark_mode),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 8),
            child: Text(
              '목표 지출 설정',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange),
            ),
          ),
          Slider(
            value: goalExpense.toDouble(),
            min: 0,
            max: 3000000,
            divisions: 100,
            label: '$goalExpense 원',
            onChanged: (value) => onGoalExpenseChanged(value.toInt()),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              '현재 목표: $goalExpense 원',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.deepOrange),
            ),
          ),
          const Divider(),

          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.red),
            title: const Text(
              '모든 데이터 초기화',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('경고'),
                  content: const Text('모든 데이터가 삭제됩니다. 계속하시겠습니까?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('취소'),
                    ),
                    TextButton(
                      onPressed: () {
                        onResetData();
                        Navigator.of(context).pop();
                      },
                      child: const Text('삭제', style: TextStyle(color: Colors.red)),
                    ),
                  ],
                ),
              );
            },
          ),

          const Divider(),

          // 📘 도움말 항목
          ListTile(
            leading: const Icon(Icons.help_outline, color: Colors.teal),
            title: const Text(
              '도움말',
              style: TextStyle(color: Colors.black),
            ),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('도움말 기능은 아직 구현되지 않았습니다.'),
                ),
              );
            },
          ),

          const SizedBox(height: 40),
          const Center(child: Text('버전 1.0.0', style: TextStyle(color: Colors.grey))),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
