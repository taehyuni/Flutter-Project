import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class ExpensePage extends StatefulWidget {
  const ExpensePage({super.key});

  @override
  State<ExpensePage> createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  final Map<DateTime, List<String>> _expenses = {};

  List<String> _getExpensesForDay(DateTime day) {
    return _expenses[DateTime.utc(day.year, day.month, day.day)] ?? [];
  }

  void _addExpense(DateTime date, String expense) {
    final key = DateTime.utc(date.year, date.month, date.day);
    if (!_expenses.containsKey(key)) {
      _expenses[key] = [];
    }
    _expenses[key]!.add(expense);
  }

  void _removeExpense(DateTime date, String expense) {
    final key = DateTime.utc(date.year, date.month, date.day);
    _expenses[key]?.remove(expense);
  }

  void _showExpenseDialog(DateTime date) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${date.year}년 ${date.month}월 ${date.day}일 지출'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: controller,
              decoration: const InputDecoration(labelText: '지출 내역 입력'),
            ),
            const SizedBox(height: 10),
            ..._getExpensesForDay(date).map((expense) => ListTile(
              title: Text(expense),
              trailing: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  setState(() {
                    _removeExpense(date, expense);
                  });
                  Navigator.of(context).pop();
                },
              ),
            )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              final text = controller.text.trim();
              if (text.isNotEmpty) {
                setState(() {
                  _addExpense(date, text);
                });
              }
              Navigator.of(context).pop();
            },
            child: const Text('저장'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Text(
            '지출',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        TableCalendar(
          focusedDay: _focusedDay,
          firstDay: DateTime(2000),
          lastDay: DateTime(2100),
          selectedDayPredicate: (day) =>
          _selectedDay != null && isSameDay(day, _selectedDay),
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDay = selectedDay;
              _focusedDay = focusedDay;
            });
            _showExpenseDialog(selectedDay);
          },
          calendarStyle: const CalendarStyle(
            markerDecoration: BoxDecoration(
              color: Colors.deepOrange,
              shape: BoxShape.circle,
            ),
          ),
          eventLoader: _getExpensesForDay,
          headerStyle: const HeaderStyle(
            formatButtonVisible: false,  // "2 weeks" 버튼 숨김
          ),
        ),
        const SizedBox(height: 8),
        if (_selectedDay != null)
          ..._getExpensesForDay(_selectedDay!).map((e) => ListTile(title: Text(e))),
      ],
    );
  }
}
