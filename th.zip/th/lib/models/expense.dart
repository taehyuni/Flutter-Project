import 'package:hive/hive.dart';

part 'expense.g.dart';

@HiveType(typeId: 1)
class Expense extends HiveObject {
  @HiveField(0)
  DateTime date;

  @HiveField(1)
  String type; // '수입' or '지출'

  @HiveField(2)
  String category;

  @HiveField(3)
  String detail;

  @HiveField(4)
  int amount;

  @HiveField(5)
  DateTime timestamp;

  Expense({
    required this.date,
    required this.type,
    required this.category,
    required this.detail,
    required this.amount,
    required this.timestamp,
  });
}
