import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/expense.dart';
import 'package:intl/intl.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

class ExpensePage extends StatefulWidget {
  const ExpensePage({super.key});

  @override
  State<ExpensePage> createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  late Box<Expense> _expenseBox;
  late Box _categoryBox;

  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  String _selectedCategoryFilter = '카테고리';
  String _viewFilter = '지출, 수입';

  List<String> _expenseCategories = ['기타', '음식', '의류', '교통', '의료', '여가'];
  final List<String> _incomeCategories = ['기타', '월급', '보너스', '이자'];

  @override
  void initState() {
    super.initState();
    _expenseBox = Hive.box<Expense>('expenses');
    _categoryBox = Hive.box('categorie');
    _loadCategories();
  }

  void _loadCategories() {
    final saved = _categoryBox.get('expenseCategories');
    _expenseCategories = (saved as List<dynamic>? ?? _expenseCategories)
        .map((e) => e.toString())
        .toList();
    _categoryBox.put('expenseCategories', _expenseCategories);
  }

  void _saveCategories() {
    _categoryBox.put('expenseCategories', _expenseCategories);
  }

  DateTime _getDateKey(DateTime date) =>
      DateTime.utc(date.year, date.month, date.day);

  List<Expense> _getExpensesForDay(DateTime day) {
    final key = _getDateKey(day);
    var result = _expenseBox.values
        .where((e) => _getDateKey(e.date) == key)
        .toList();

    if (_viewFilter == '수입') {
      result = result.where((e) => e.type == '수입').toList();
    } else if (_viewFilter == '지출') {
      result = result.where((e) => e.type == '지출').toList();
    }

    if (_selectedCategoryFilter != '카테고리') {
      result = result.where((e) => e.category == _selectedCategoryFilter).toList();
    }

    return result;
  }

  Map<String, int> _getIncomeExpenseTotal(DateTime day) {
    final list = _expenseBox.values
        .where((e) => _getDateKey(e.date) == _getDateKey(day))
        .toList();
    final income = list.where((e) => e.type == '수입').fold(0, (s, e) => s + e.amount);
    final expense = list.where((e) => e.type == '지출').fold(0, (s, e) => s + e.amount);
    return {'income': income, 'expense': expense};
  }

  Future<void> _addExpense(Expense entry) async {
    await _expenseBox.add(entry);
    if (mounted) setState(() {});
  }

  Future<void> _removeExpense(Expense entry) async {
    await entry.delete();
    if (mounted) setState(() {});
  }

  void _showExpenseDialog(DateTime date, {bool isIncome = false}) {
    final items = isIncome ? _incomeCategories : _expenseCategories;
    String selectedCategory = items.first;
    final detailCtrl = TextEditingController();
    final amountCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: const Color(0xFFFFFAF3),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${date.year}년 ${date.month}월 ${date.day}일 ${isIncome ? '수입' : '지출'} 추가',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF6B4E16),
                  ),
                ),
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: InputDecoration(
                    hintText: '카테고리 선택',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                  items: items.map((cat) => DropdownMenuItem(value: cat, child: Text(cat))).toList(),
                  onChanged: (v) {
                    if (v != null) selectedCategory = v;
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: detailCtrl,
                  decoration: InputDecoration(
                    hintText: '상세내역을 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: '금액을 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B4E16),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () async {
                        final detail = detailCtrl.text.trim();
                        final amount = int.tryParse(amountCtrl.text.trim());
                        if (detail.isEmpty || amount == null || amount <= 0) {
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('입력 오류'),
                              content: const Text('올바른 금액을 입력해주세요.'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('확인'),
                                ),
                              ],
                            ),
                          );
                          return;
                        }
                        final entry = Expense(
                          date: date,
                          type: isIncome ? '수입' : '지출',
                          category: selectedCategory,
                          detail: detail,
                          amount: amount,
                          timestamp: DateTime.now(),
                        );
                        await _addExpense(entry);
                        Navigator.pop(context);
                      },
                      child: const Text('저장'),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('취소', style: TextStyle(color: Colors.grey)),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showCategoryManager() {
    final ctrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, st) => Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          backgroundColor: const Color(0xFFFFFAF3),
          insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(
                    child: Text(
                      '지출 카테고리 관리',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF6B4E16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: _expenseCategories.map((cat) {
                      return Chip(
                        label: Text(cat),
                        backgroundColor: Colors.white,
                        deleteIcon: cat == '기타' ? null : const Icon(Icons.close, size: 18),
                        onDeleted: cat == '기타'
                            ? null
                            : () {
                          st(() {
                            _expenseCategories.remove(cat);
                            _saveCategories();
                            if (_selectedCategoryFilter == cat) {
                              _selectedCategoryFilter = '카테고리';
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: ctrl,
                    decoration: InputDecoration(
                      hintText: '새 카테고리 이름 입력',
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.all(12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFBFA87C),
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6B4E16),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        onPressed: () {
                          final newCat = ctrl.text.trim();
                          if (newCat.isNotEmpty && !_expenseCategories.contains(newCat)) {
                            st(() {
                              _expenseCategories.add(newCat);
                              _saveCategories();
                            });
                          }
                        },
                        child: const Text('추가'),
                      ),
                      const SizedBox(width: 10),
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('닫기', style: TextStyle(color: Colors.grey)),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


  List<String> _getCategoryOptions() {
    final options = <String>['카테고리'];
    if (_viewFilter == '수입') {
      options.addAll(_incomeCategories);
    } else {
      options.addAll(_expenseCategories);
    }
    return options;
  }

  @override
  Widget build(BuildContext context) {
    final expenses = _selectedDay != null ? _getExpensesForDay(_selectedDay!) : [];
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      body: Column(
        children: [
          const SizedBox(height: 16),
          TableCalendar(
            focusedDay: _focusedDay,
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            rowHeight: 60,
            selectedDayPredicate: (d) => _selectedDay != null && isSameDay(d, _selectedDay),
            onDaySelected: (sel, foc) {
              setState(() {
                _selectedDay = sel;
                _focusedDay = foc;
              });
            },
            calendarStyle: const CalendarStyle(
              markersMaxCount: 0,
              todayDecoration: BoxDecoration(color: Color(0xFFE6D3B3), shape: BoxShape.circle),
              selectedDecoration: BoxDecoration(color: Color(0xFF6B4E16), shape: BoxShape.circle),
              selectedTextStyle: TextStyle(color: Colors.white),
            ),
            headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (ctx, day, _) {
                final t = _getIncomeExpenseTotal(day);
                final fmt = NumberFormat('#,###');
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('${day.day}', style: const TextStyle(fontSize: 14)),
                    if (t['income']! > 0) Text('+${fmt.format(t['income'])}', style: const TextStyle(fontSize: 10, color: Colors.blue)),
                    if (t['expense']! > 0) Text('-${fmt.format(t['expense'])}', style: const TextStyle(fontSize: 10, color: Colors.red)),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          if (_selectedDay != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text(
                    '${_selectedDay!.year}년 ${_selectedDay!.month}월 ${_selectedDay!.day}일 내역',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 8),
                  _buildStyledDropdown2(
                    _selectedCategoryFilter,
                    _getCategoryOptions(),
                        (v) => setState(() => _selectedCategoryFilter = v),
                  ),
                  const SizedBox(width: 8),
                  _buildStyledDropdown2(
                    _viewFilter,
                    ['지출, 수입', '수입', '지출'],
                        (v) {
                      setState(() {
                        _viewFilter = v;
                        _selectedCategoryFilter = '카테고리';
                      });
                    },
                  ),
                  const Spacer(),
                  _buildStyledButton('카테고리', _showCategoryManager),
                  const SizedBox(width: 8),
                  _buildStyledButton('지출 추가', () => _showExpenseDialog(_selectedDay!, isIncome: false)),
                  const SizedBox(width: 8),
                  _buildStyledButton('수입 추가', () => _showExpenseDialog(_selectedDay!, isIncome: true)),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: expenses.isEmpty
                ? const Center(child: Text('날짜를 선택해주세요.', style: TextStyle(color: Colors.grey)))
                : ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: expenses.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (c, i) {
                final e = expenses[i];
                final time = DateFormat('HH:mm').format(e.timestamp);
                final fmt = NumberFormat('#,###');
                final isIncome = e.type == '수입';

                return Card(
                  color: const Color(0xFFFFFAF3),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(time, style: const TextStyle(color: Colors.grey, fontSize: 13)),
                        const SizedBox(height: 4),
                        Text('${e.category} - ${e.detail}',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              '${isIncome ? '+' : '-'} ${fmt.format(e.amount)}원',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: isIncome ? Colors.blue : Colors.red,
                              ),
                            ),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _removeExpense(e),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyledDropdown2(String current, List<String> options, ValueChanged<String> onChanged) {
    return SizedBox(
      height: 36,
      width: 104,
      child: DropdownButtonHideUnderline(
        child: DropdownButton2<String>(
          isExpanded: true,
          value: options.contains(current) ? current : options.first,
          onChanged: (v) => onChanged(v!),
          items: options.map((opt) => DropdownMenuItem(
            value: opt,
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                opt,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  letterSpacing: 0.1,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          )).toList(),
          buttonStyleData: ButtonStyleData(
            height: 36,
            width: 104,
            decoration: BoxDecoration(
              color: const Color(0xFF6B4E16),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.brown.withOpacity(0.10),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
          ),
          dropdownStyleData: DropdownStyleData(
            maxHeight: 320,
            width: 104,
            decoration: BoxDecoration(
              color: const Color(0xFF7A5A23),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            offset: const Offset(0, 0),
          ),
          iconStyleData: const IconStyleData(
            icon: Icon(Icons.arrow_drop_down_rounded, color: Colors.white, size: 22),
          ),
          style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
          menuItemStyleData: const MenuItemStyleData(
            overlayColor: MaterialStatePropertyAll(Color(0x22FFFFFF)),
            height: 40,
          ),
        ),
      ),
    );
  }




  Widget _buildStyledButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF6B4E16),
        foregroundColor: Colors.white,
        elevation: 1,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 13)),
    );
  }
}
