import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/expense.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

class StatsPage extends StatefulWidget {
  final int goalExpense;
  const StatsPage({super.key, required this.goalExpense});

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  late Box<Expense> _expenseBox;
  final ValueNotifier<String> _period = ValueNotifier<String>('이번 달');

  @override
  void initState() {
    super.initState();
    _expenseBox = Hive.box<Expense>('expenses');
  }

  @override
  void dispose() {
    _period.dispose();
    super.dispose();
  }

  List<Expense> getFiltered(String period, Iterable<Expense> allExpenses) {
    final now = DateTime.now();
    late DateTime start;
    late DateTime end;

    switch (period) {
      case '오늘':
        start = DateTime(now.year, now.month, now.day);
        end = start.add(const Duration(days: 1));
        break;
      case '이번 주':
        start = now.subtract(Duration(days: now.weekday - 1));
        start = DateTime(start.year, start.month, start.day);
        end = start.add(const Duration(days: 7));
        break;
      case '올해':
        start = DateTime(now.year, 1, 1);
        end = DateTime(now.year + 1, 1, 1);
        break;
      case '이번 달':
      default:
        start = DateTime(now.year, now.month, 1);
        end = (now.month < 12)
            ? DateTime(now.year, now.month + 1, 1)
            : DateTime(now.year + 1, 1, 1);
    }

    return allExpenses.where((e) {
      final date = DateTime(e.date.year, e.date.month, e.date.day);
      return !date.isBefore(start) && date.isBefore(end);
    }).toList();
  }

  Widget _buildDropdown() {
    return SizedBox(
      height: 36,
      width: 104,
      child: ValueListenableBuilder(
        valueListenable: _period,
        builder: (context, value, _) => DropdownButtonHideUnderline(
          child: DropdownButton2<String>(
            isExpanded: true,
            value: value,
            onChanged: (val) {
              if (val != null) _period.value = val;
            },
            items: ['오늘', '이번 주', '이번 달', '올해']
                .map((e) => DropdownMenuItem(
              value: e,
              child: Center(
                child: Text(
                  e,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    letterSpacing: 0.1,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            )).toList(),
            buttonStyleData: ButtonStyleData(
              height: 36,
              width: 104,
              decoration: BoxDecoration(
                color: const Color(0xFF6B4E16),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.brown.withOpacity(0.10),
                    blurRadius: 4,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
            ),
            dropdownStyleData: DropdownStyleData(
              maxHeight: 320,
              width: 104,
              decoration: BoxDecoration(
                color: const Color(0xFF7A5A23),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.10),
                    blurRadius: 12,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              offset: const Offset(0, 0),
            ),
            iconStyleData: const IconStyleData(
              icon: Icon(Icons.arrow_drop_down_rounded, color: Colors.white, size: 22),
            ),
            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
            menuItemStyleData: const MenuItemStyleData(
              overlayColor: MaterialStatePropertyAll(Color(0x22FFFFFF)),
              height: 42,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryBox(String label, int amount, Color color) {
    final formatter = NumberFormat('#,###');
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFAF3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color),
        ),
        child: Column(
          children: [
            Text(label, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: color)),
            const SizedBox(height: 6),
            Text('${formatter.format(amount)}원', style: TextStyle(color: color)),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetSummaryBox(int goalExpense, int remaining) {
    final formatter = NumberFormat('#,###');
    final isOver = remaining < 0;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFAF3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              '목표 : ${formatter.format(goalExpense)}원',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '${isOver ? '초과지출 : ' : '남은지출 : '} ${formatter.format(remaining.abs())}원',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: isOver ? Colors.red : Colors.green,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPieChart(List<Expense> filtered) {
    final categoryMap = <String, int>{};
    final total = filtered.where((e) => e.type == '지출').fold(0, (sum, e) => sum + e.amount);
    for (var e in filtered.where((e) => e.type == '지출')) {
      categoryMap[e.category] = (categoryMap[e.category] ?? 0) + e.amount;
    }

    if (categoryMap.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 40),
          child: Text(
            '지출 데이터 없음',
            style: TextStyle(fontSize: 16, color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    final entries = categoryMap.entries.toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 200,
          child: PieChart(
            PieChartData(
              sections: entries.asMap().entries.map((entry) {
                final index = entry.key;
                final e = entry.value;
                final color = Colors.primaries[index % Colors.primaries.length];
                return PieChartSectionData(
                  value: e.value.toDouble(),
                  title: '${((e.value / total) * 100).toStringAsFixed(1)}%',
                  color: color,
                  radius: 50,
                  titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                );
              }).toList(),
              sectionsSpace: 2,
              centerSpaceRadius: 32,
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('카테고리별 지출 비율', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 12,
          children: entries.asMap().entries.map((entry) {
            final index = entry.key;
            final e = entry.value;
            final color = Colors.primaries[index % Colors.primaries.length];
            final percent = ((e.value / total) * 100).toStringAsFixed(1);
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 12, height: 12, color: color),
                const SizedBox(width: 4),
                Text('${e.key} ($percent%)'),
              ],
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDailyList(List<Expense> filtered) {
    final formatter = NumberFormat('#,###');
    final map = <DateTime, List<Expense>>{};
    for (var e in filtered) {
      final key = DateTime(e.date.year, e.date.month, e.date.day);
      map.putIfAbsent(key, () => []);
      map[key]!.add(e);
    }

    final dates = map.keys.toList()..sort((a, b) => b.compareTo(a));

    return Column(
      children: dates.map((date) {
        final items = map[date]!;

        final sortedItems = [...items]..sort((a, b) {
          if (a.type == b.type) return 0;
          return a.type == '지출' ? -1 : 1;
        });

        return Card(
          color: const Color(0xFFFFFDF7),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(DateFormat('yyyy.MM.dd').format(date), style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                ...sortedItems.map((e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${e.type} : ${e.detail}'),
                      Text('${e.type == '지출' ? '-' : '+'}${formatter.format(e.amount)}원',
                          style: TextStyle(color: e.type == '지출' ? Colors.red : Colors.blue)),
                    ],
                  ),
                )),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          children: [
            const Text('지출 통계', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black)),
            const SizedBox(width: 12),
            _buildDropdown(),
          ],
        ),
      ),
      body: AnimatedBuilder(
        animation: Listenable.merge([_expenseBox.listenable(), _period]),
        builder: (context, _) {
          final allExpenses = _expenseBox.values.toList();
          final filtered = getFiltered(_period.value, allExpenses);
          final totalExpense = filtered.where((e) => e.type == '지출').fold(0, (sum, e) => sum + e.amount);
          final totalIncome = filtered.where((e) => e.type == '수입').fold(0, (sum, e) => sum + e.amount);
          final remaining = widget.goalExpense - totalExpense;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildSummaryBox('총 지출', totalExpense, Colors.red),
                    _buildSummaryBox('총 수입', totalIncome, Colors.blue),
                    _buildBudgetSummaryBox(widget.goalExpense, remaining)
                  ],
                ),
                const SizedBox(height: 20),
                _buildPieChart(filtered),
                const SizedBox(height: 24),
                const Text('날짜별 내역', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                _buildDailyList(filtered),
              ],
            ),
          );
        },
      ),
    );
  }
}
