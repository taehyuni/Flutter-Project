import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'DiaryPage.dart';
import 'ExpensePage.dart';
import 'StatsPage.dart';
import 'SettingsPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  // Settings 관련 상태를 여기서 관리
  bool _isDarkMode = false;
  double _fontSize = 16;

  // 목표 지출 상태 추가 (기본값 50000)
  int _goalExpense = 50000;

  // 초기 데이터는 빈 리스트 (예시)
  final List<String> todayMemos = [];
  final List<String> todayExpenses = [];
  final List<String> recentExpenses = [];

  @override
  Widget build(BuildContext context) {
    // 페이지 리스트에 SettingsPage에 필요한 인자 전달
    final List<Widget> _pages = [
      const HomeScreen(),
      const DiaryPage(),
      const ExpensePage(),
      const StatsPage(),
      SettingsPage(
        isDarkMode: _isDarkMode,
        onThemeChanged: (bool value) {
          setState(() {
            _isDarkMode = value;
          });
        },
        fontSize: _fontSize,
        onFontSizeChanged: (double value) {
          setState(() {
            _fontSize = value;
          });
        },
        onResetData: () {
          // TODO: 초기화 로직 작성
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('데이터가 초기화되었습니다.')),
          );
        },
        goalExpense: _goalExpense,
        onGoalExpenseChanged: (int value) {
          setState(() {
            _goalExpense = value;
          });
        },
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              DateFormat('yyyy년 MM월 dd일').format(DateTime.now()),
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        backgroundColor: const Color(0xFFE6D3B3),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        backgroundColor: const Color(0xFFF5F5DC),
        selectedItemColor: const Color(0xFF6B4E16),
        unselectedItemColor: Colors.brown[200],
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: '홈'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: '다이어리'),
          BottomNavigationBarItem(icon: Icon(Icons.attach_money), label: '지출'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: '통계'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: '설정'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // 임시 데이터: 실제 앱에서는 상태 관리나 DB 연동 필요
    final List<String> todayMemos = [];
    final List<String> todayExpenses = [];
    final List<String> recentExpenses = [];

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionCard(
              title: '오늘의 메모',
              items: todayMemos,
              emptyMessage: '오늘의 메모가 없습니다.',
              onAddPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('메모 추가 버튼 클릭')),
                );
              },
            ),
            const SizedBox(height: 16),
            SectionCard(
              title: '오늘의 지출',
              items: todayExpenses,
              emptyMessage: '오늘의 지출 내역이 없습니다.',
              onAddPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('지출 추가 버튼 클릭')),
                );
              },
            ),
            const SizedBox(height: 16),
            SectionCard(
              title: '최근 지출',
              items: recentExpenses,
              emptyMessage: '최근 지출 내역이 없습니다.',
              onAddPressed: null, // 최근 지출은 추가 버튼 없음
            ),
          ],
        ),
      ),
    );
  }
}

class SectionCard extends StatelessWidget {
  final String title;
  final List<String> items;
  final String emptyMessage;
  final VoidCallback? onAddPressed;

  const SectionCard({
    super.key,
    required this.title,
    required this.items,
    required this.emptyMessage,
    this.onAddPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFEFE6CF),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 제목과 추가 버튼(있을 때만)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF6B4E16),
                  ),
                ),
                if (onAddPressed != null)
                  ElevatedButton.icon(
                    onPressed: onAddPressed,
                    icon: const Icon(Icons.add),
                    label: const Text('추가'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6B4E16),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),

            // 아이템 리스트 또는 비어있을 때 메시지
            if (items.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  emptyMessage,
                  style: const TextStyle(
                    fontSize: 16,
                    fontStyle: FontStyle.italic,
                    color: Colors.brown,
                  ),
                ),
              )
            else
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: items
                    .map((item) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text(
                    '- $item',
                    style: const TextStyle(fontSize: 16),
                  ),
                ))
                    .toList(),
              ),
          ],
        ),
      ),
    );
  }
}
