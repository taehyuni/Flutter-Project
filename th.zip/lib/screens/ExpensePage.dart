import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/expense.dart';
import 'package:intl/intl.dart';

class ExpensePage extends StatefulWidget {
  const ExpensePage({super.key});

  @override
  State<ExpensePage> createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  late Box<Expense> _expenseBox;
  late Box _categoryBox;

  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  String _selectedCategoryFilter = '전체보기';
  String _viewFilter = '모두보기';

  List<String> _categories = ['음식', '의류', '교통', '의료', '여가'];

  @override
  void initState() {
    super.initState();
    _expenseBox = Hive.box<Expense>('expenses');
    _categoryBox = Hive.box('categorie');
    _loadCategories();
  }

  void _loadCategories() {
    final savedCategories = _categoryBox.get('expenseCategories');
    _categories = (savedCategories as List<dynamic>? ?? ['음식', '의류', '교통', '의료', '여가']).map((e) => e.toString()).toList();
    _categoryBox.put('expenseCategories', _categories);
  }

  void _saveCategories() {
    _categoryBox.put('expenseCategories', _categories);
  }

  DateTime _getDateKey(DateTime date) => DateTime.utc(date.year, date.month, date.day);

  List<Expense> _getExpensesForDay(DateTime day) {
    final key = _getDateKey(day);
    var result = _expenseBox.values.where((e) => _getDateKey(e.date) == key).toList();

    if (_viewFilter == '수입만') {
      result = result.where((e) => e.type == '수입').toList();
    } else if (_viewFilter == '지출만') {
      result = result.where((e) => e.type == '지출').toList();
    }

    if (_selectedCategoryFilter != '전체보기') {
      result = result.where((e) => e.category == _selectedCategoryFilter).toList();
    }

    return result;
  }

  Map<String, int> _getIncomeExpenseTotal(DateTime day) {
    final list = _expenseBox.values.where((e) => _getDateKey(e.date) == _getDateKey(day)).toList();
    int income = list.where((e) => e.type == '수입').fold(0, (sum, e) => sum + e.amount);
    int expense = list.where((e) => e.type == '지출').fold(0, (sum, e) => sum + e.amount);
    return {'income': income, 'expense': expense};
  }

  Future<void> _addExpense(Expense entry) async {
    await _expenseBox.add(entry);
    if (mounted) setState(() {});
  }

  Future<void> _removeExpense(Expense entry) async {
    await entry.delete();
    if (mounted) setState(() {});
  }

  void _showExpenseDialog(DateTime date, {bool isIncome = false}) {
    String selectedCategory = _categories.first;
    final detailController = TextEditingController();
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${date.year}년 ${date.month}월 ${date.day}일 ${isIncome ? '수입' : '지출'} 추가'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: selectedCategory,
              decoration: const InputDecoration(labelText: '카테고리'),
              items: _categories.map((cat) => DropdownMenuItem(value: cat, child: Text(cat))).toList(),
              onChanged: (value) {
                if (value != null) selectedCategory = value;
              },
            ),
            TextField(controller: detailController, decoration: const InputDecoration(labelText: '상세내역')),
            TextField(controller: amountController, decoration: const InputDecoration(labelText: '금액 입력'), keyboardType: TextInputType.number),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final detail = detailController.text.trim();
              final amount = int.tryParse(amountController.text.trim());

              if (detail.isEmpty || amount == null || amount <= 0) {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('입력 오류'),
                    content: const Text('올바른 금액을 입력해주세요.'),
                    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('확인'))],
                  ),
                );
                return;
              }

              final entry = Expense(
                date: date,
                type: isIncome ? '수입' : '지출',
                category: selectedCategory,
                detail: detail,
                amount: amount,
                timestamp: DateTime.now(),
              );

              await _addExpense(entry);
              Navigator.pop(context);
            },
            child: const Text('저장'),
          ),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
        ],
      ),
    );
  }

  void _showCategoryManager() {
    final newCategoryController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: const Text('카테고리 관리'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ..._categories.map((cat) => ListTile(
                title: Text(cat),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      _categories.remove(cat);
                      _saveCategories();
                    });
                    setStateDialog(() {});
                  },
                ),
              )),
              const Divider(),
              TextField(controller: newCategoryController, decoration: const InputDecoration(labelText: '새 카테고리 이름')),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final newCat = newCategoryController.text.trim();
                if (newCat.isNotEmpty && !_categories.contains(newCat)) {
                  setState(() {
                    _categories.add(newCat);
                    _saveCategories();
                  });
                  setStateDialog(() {});
                }
              },
              child: const Text('카테고리 추가'),
            ),
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('닫기')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Expense> expenses = _selectedDay != null ? _getExpensesForDay(_selectedDay!) : [];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(toolbarHeight: 0, backgroundColor: Colors.transparent, elevation: 0),
      body: Column(
        children: [
          const SizedBox(height: 16),
          TableCalendar(
            focusedDay: _focusedDay,
            rowHeight: 60,
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            selectedDayPredicate: (day) => _selectedDay != null && isSameDay(day, _selectedDay),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            calendarStyle: const CalendarStyle(
              markersMaxCount: 0,
              todayDecoration: BoxDecoration(color: Color(0xFFE6D3B3), shape: BoxShape.circle),
              selectedDecoration: BoxDecoration(color: Color(0xFF6B4E16), shape: BoxShape.circle),
              selectedTextStyle: TextStyle(color: Colors.white),
            ),
            headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (context, day, _) {
                final totals = _getIncomeExpenseTotal(day);
                final formatter = NumberFormat('#,###');
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('${day.day}', style: const TextStyle(fontSize: 14)),
                    if (totals['income']! > 0) Text('+${formatter.format(totals['income'])}', style: const TextStyle(fontSize: 10, color: Colors.blue)),
                    if (totals['expense']! > 0) Text('-${formatter.format(totals['expense'])}', style: const TextStyle(fontSize: 10, color: Colors.red)),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          if (_selectedDay != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Text('${_selectedDay!.year}년 ${_selectedDay!.month}월 ${_selectedDay!.day}일 내역', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  _buildStyledDropdown(_selectedCategoryFilter, ['전체보기', ..._categories], (val) => setState(() => _selectedCategoryFilter = val)),
                  const SizedBox(width: 8),
                  _buildStyledDropdown(_viewFilter, ['모두보기', '수입만', '지출만'], (val) => setState(() => _viewFilter = val)),
                  const Spacer(),
                  _buildStyledButton('카테고리', _showCategoryManager),
                  const SizedBox(width: 8),
                  _buildStyledButton('지출 추가', () => _showExpenseDialog(_selectedDay!, isIncome: false)),
                  const SizedBox(width: 8),
                  _buildStyledButton('수입 추가', () => _showExpenseDialog(_selectedDay!, isIncome: true)),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: expenses.isEmpty
                ? const Center(child: Text('내역이 없습니다.', style: TextStyle(color: Colors.grey)))
                : ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: expenses.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final entry = expenses[index];
                final time = DateFormat('HH:mm').format(entry.timestamp);
                final formatter = NumberFormat('#,###');
                final isIncome = entry.type == '수입';

                return Card(
                  color: const Color(0xFFFFFAF3),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(time, style: const TextStyle(color: Colors.grey, fontSize: 13)),
                        const SizedBox(height: 4),
                        Text('${entry.category} - ${entry.detail}',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              '${isIncome ? '+' : '-'} ${formatter.format(entry.amount)}원',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: isIncome ? Colors.blue : Colors.red,
                              ),
                            ),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.redAccent),
                              onPressed: () => _removeExpense(entry),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyledDropdown(String currentValue, List<String> options, ValueChanged<String> onChanged) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF6B4E16),
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButton<String>(
        value: currentValue,
        onChanged: (val) => onChanged(val!),
        dropdownColor: const Color(0xFF6B4E16),
        icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
        underline: const SizedBox(),
        style: const TextStyle(color: Colors.white, fontSize: 13),
        items: options.map((opt) {
          return DropdownMenuItem<String>(
            value: opt,
            child: Text(opt, style: const TextStyle(color: Colors.white)),
          );
        }).toList(),
      ),
    );
  }


  Widget _buildStyledButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF6B4E16),
        foregroundColor: Colors.white,
        elevation: 1,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      child: Text(label),
    );
  }
}
