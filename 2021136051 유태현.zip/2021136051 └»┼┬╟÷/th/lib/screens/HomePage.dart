import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/memo.dart';
import '../models/expense.dart';
import 'DiaryPage.dart';
import 'ExpensePage.dart';
import 'StatsPage.dart';
import 'SettingsPage.dart';

Future<void> saveGoalExpense(int value) async {
  var box = await Hive.openBox('settings');
  await box.put('goalExpense', value);
}

Future<int> loadGoalExpense() async {
  var box = await Hive.openBox('settings');
  return box.get('goalExpense', defaultValue: 500000);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Box<Memo> _memoBox;
  late Box<Expense> _expenseBox;

  DateTime today = DateTime.now();
  int _selectedIndex = 0;

  double fontSize = 16;
  int? goalExpense;

  @override
  void initState() {
    super.initState();
    _memoBox = Hive.box<Memo>('memos');
    _expenseBox = Hive.box<Expense>('expenses');

    loadGoalExpense().then((val) {
      if (mounted) setState(() => goalExpense = val);
    });
  }

  DateTime _getDateKey(DateTime date) => DateTime.utc(date.year, date.month, date.day);

  List<Memo> _getTodayMemos() => _memoBox.values.where((m) => _getDateKey(m.date) == _getDateKey(today)).toList();

  List<Expense> _getTodayExpenses() => _expenseBox.values.where((e) => _getDateKey(e.date) == _getDateKey(today) && e.type == '지출').toList();

  List<Expense> _getTodayIncomes() => _expenseBox.values.where((e) => _getDateKey(e.date) == _getDateKey(today) && e.type == '수입').toList();

  List<Expense> _getRecentExpenses() {
    final todayKey = _getDateKey(today);
    final recentDate = _expenseBox.values
        .where((e) => e.type == '지출' && _getDateKey(e.date).isBefore(todayKey))
        .map((e) => _getDateKey(e.date))
        .toSet()
        .fold<DateTime?>(null, (prev, d) => prev == null || d.isAfter(prev) ? d : prev);

    if (recentDate == null) return [];
    return _expenseBox.values.where((e) => _getDateKey(e.date) == recentDate && e.type == '지출').toList();
  }

  List<Expense> _getRecentIncomes() {
    final todayKey = _getDateKey(today);
    final recentDate = _expenseBox.values
        .where((e) => e.type == '수입' && _getDateKey(e.date).isBefore(todayKey))
        .map((e) => _getDateKey(e.date))
        .toSet()
        .fold<DateTime?>(null, (prev, d) => prev == null || d.isAfter(prev) ? d : prev);

    if (recentDate == null) return [];
    return _expenseBox.values.where((e) => _getDateKey(e.date) == recentDate && e.type == '수입').toList();
  }

  int _getThisMonthTotalExpense() {
    final firstDay = DateTime(today.year, today.month, 1);
    return _expenseBox.values
        .where((e) => e.type == '지출' && e.date.isAfter(firstDay.subtract(const Duration(days: 1))) && e.date.isBefore(today.add(const Duration(days: 1))))
        .fold(0, (sum, e) => sum + e.amount);
  }

  int _getThisMonthTotalIncome() {
    final firstDay = DateTime(today.year, today.month, 1);
    return _expenseBox.values
        .where((e) => e.type == '수입' && e.date.isAfter(firstDay.subtract(const Duration(days: 1))) && e.date.isBefore(today.add(const Duration(days: 1))))
        .fold(0, (sum, e) => sum + e.amount);
  }

  void _resetData() async {
    await _memoBox.clear();
    await _expenseBox.clear();
    if (mounted) setState(() {});
  }

  void _addMemo() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: const Color(0xFFFFFAF3),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '오늘의 메모 추가',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF6B4E16),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: controller,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: '오늘의 메모를 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B4E16),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () async {
                        final text = controller.text.trim();
                        if (text.isNotEmpty) {
                          await _memoBox.add(Memo(date: today, content: text));
                          setState(() {});
                        }
                        Navigator.of(context).pop();
                      },
                      child: const Text('저장'),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('취소', style: TextStyle(color: Colors.grey)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _addExpense({required bool isIncome}) {
    final todayDate = today;
    final expenseCategories = ['기타', '음식', '의류', '교통', '의료', '여가'];
    final incomeCategories = ['기타', '월급', '보너스', '이자'];
    final categoryItems = isIncome ? incomeCategories : expenseCategories;

    String selectedCategory = categoryItems.first;
    final detailController = TextEditingController();
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: const Color(0xFFFFFAF3),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '오늘의 ${isIncome ? '수입' : '지출'} 추가',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF6B4E16),
                  ),
                ),
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: InputDecoration(
                    hintText: '카테고리 선택',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                  items: categoryItems
                      .map((cat) => DropdownMenuItem(value: cat, child: Text(cat)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) selectedCategory = v;
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: detailController,
                  decoration: InputDecoration(
                    hintText: '상세내역을 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: '금액을 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B4E16),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () async {
                        final detail = detailController.text.trim();
                        final amount = int.tryParse(amountController.text.trim());

                        if (detail.isEmpty || amount == null || amount <= 0) {
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('입력 오류'),
                              content: const Text('올바른 금액을 입력해주세요.'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('확인'),
                                ),
                              ],
                            ),
                          );
                          return;
                        }

                        await _expenseBox.add(
                          Expense(
                            date: todayDate,
                            type: isIncome ? '수입' : '지출',
                            category: selectedCategory,
                            detail: detail,
                            amount: amount,
                            timestamp: DateTime.now(),
                          ),
                        );

                        if (mounted) setState(() {});
                        Navigator.pop(context);
                      },
                      child: const Text('저장'),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('취소', style: TextStyle(color: Colors.grey)),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    final formatter = NumberFormat('#,###');
    final memoItems = _getTodayMemos().map((e) => e.content).toList();
    final expenseItems = _getTodayExpenses().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final incomeItems = _getTodayIncomes().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final recentExpenses = _getRecentExpenses().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final recentIncomes = _getRecentIncomes().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 5,
            color: Colors.white,
            shadowColor: Colors.brown.withOpacity(0.2),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('📓 오늘의 메모', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                      const Spacer(),
                      IconButton(
                        onPressed: _addMemo,
                        icon: const Icon(Icons.add_circle_outline, color: Color(0xFF5A3E1D)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  memoItems.isEmpty
                      ? const Text('메모가 없습니다.', style: TextStyle(color: Colors.grey))
                      : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: memoItems.map((e) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text('• $e', style: const TextStyle(fontSize: 15)),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(child: _buildBox('💸 오늘의 지출', expenseItems, () => _addExpense(isIncome: false))),
              const SizedBox(width: 12),
              Expanded(child: _buildBox('💰 오늘의 수입', incomeItems, () => _addExpense(isIncome: true))),
            ],
          ),

          const SizedBox(height: 16),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 4,
            color: Colors.white,
            shadowColor: Colors.brown.withOpacity(0.2),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('📅 이번달 요약', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: _buildSummary('총 지출', _getThisMonthTotalExpense(), Colors.red)),
                      const SizedBox(width: 12),
                      Expanded(child: _buildSummary('총 수입', _getThisMonthTotalIncome(), Colors.green)),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          if (recentExpenses.isNotEmpty)
            _buildBox('🧾 최근 지출', recentExpenses, null),
          if (recentIncomes.isNotEmpty)
            _buildBox('🧾 최근 수입', recentIncomes, null),
        ],
      ),
    );
  }

  Widget _buildBox(String title, List<String> items, VoidCallback? onAdd) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.brown.withOpacity(0.2),
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                const Spacer(),
                if (onAdd != null)
                  IconButton(
                    onPressed: onAdd,
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF5A3E1D)),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            items.isEmpty
                ? const Text('내역이 없습니다.', style: TextStyle(color: Colors.grey))
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: items.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text('• $e', style: const TextStyle(fontSize: 15)),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummary(String title, int amount, Color color) {
    final formatter = NumberFormat('#,###');
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 14)),
          const SizedBox(height: 4),
          Text('${formatter.format(amount)}원', style: TextStyle(color: color, fontSize: 16)),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    if (goalExpense == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      _buildBody(),
      const DiaryPage(),
      const ExpensePage(),
      StatsPage(goalExpense: goalExpense!),
      SettingsPage(
        notificationsEnabled: true,
        onNotificationsChanged: (val) {},
        goalExpense: goalExpense!,
        onGoalExpenseChanged: (val) async {
          setState(() => goalExpense = val);
          await saveGoalExpense(val);
        },
        onResetData: _resetData,
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF2E6D0),
        centerTitle: true,
        title: Text(
          DateFormat('yyyy년 MM월 dd일').format(today),
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF4B3621),
          ),
        ),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        backgroundColor: const Color(0xFFF5F5DC),
        selectedItemColor: const Color(0xFF6B4E16),
        unselectedItemColor: Colors.brown[200],
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: '홈'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: '다이어리'),
          BottomNavigationBarItem(icon: Icon(Icons.attach_money), label: '지출'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: '통계'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: '설정'),
        ],
      ),
    );
  }
}
