import 'package:flutter/material.dart';
import 'HelpPage.dart';

class SettingsPage extends StatefulWidget {
  final bool notificationsEnabled;
  final Function(bool) onNotificationsChanged;
  final int goalExpense;
  final Function(int) onGoalExpenseChanged;
  final VoidCallback onResetData;

  const SettingsPage({
    Key? key,
    required this.notificationsEnabled,
    required this.onNotificationsChanged,
    required this.goalExpense,
    required this.onGoalExpenseChanged,
    required this.onResetData,
  }) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController goalCtrl;

  @override
  void initState() {
    super.initState();
    goalCtrl = TextEditingController(text: widget.goalExpense.toString());
  }

  @override
  void didUpdateWidget(covariant SettingsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.goalExpense != widget.goalExpense) {
      goalCtrl.text = widget.goalExpense.toString();
    }
  }

  @override
  void dispose() {
    goalCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brown = const Color(0xFF6B4E16);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(56 + 18),
        child: Column(
          children: [
            const SizedBox(height: 18),
            AppBar(
              title: const Text(
                '설정',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              backgroundColor: const Color(0xFFFFF8E7),
              foregroundColor: brown,
              elevation: 0,
            ),
          ],
        ),
      ),
      backgroundColor: const Color(0xFFFFF8E7),
      body: ListView(
        children: [
          const SizedBox(height: 10),
          _SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionLabel(label: '환경 설정', color: brown),
                const SizedBox(height: 6),
                Text(
                  '원하는 스타일로 앱을 자유롭게 꾸며보세요.',
                  style: TextStyle(
                    color: Colors.brown[200],
                    fontSize: 14.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          _SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionLabel(label: '알림 설정', color: brown),
                SwitchListTile(
                  title: const Text('지출 알림', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  value: widget.notificationsEnabled,
                  onChanged: widget.onNotificationsChanged,
                  activeColor: Colors.deepOrange,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ],
            ),
          ),
          _SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionLabel(label: '지출 설정', color: brown),
                const SizedBox(height: 8),
                const Text('목표 지출 설정',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.deepOrange)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Focus(
                        onFocusChange: (hasFocus) {
                          if (!hasFocus) {
                            final num = int.tryParse(goalCtrl.text.replaceAll(',', '')) ?? 0;
                            if (num != widget.goalExpense) {
                              widget.onGoalExpenseChanged(num);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("목표 지출이 ${num.toString()}원으로 저장되었습니다.")),
                              );
                            }
                          }
                        },
                        child: TextField(
                          controller: goalCtrl,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            hintText: '목표 금액 입력',
                            prefixIcon: const Icon(Icons.flag_rounded, color: Colors.deepOrange, size: 22),
                            contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            filled: true,
                            fillColor: Colors.white,
                          ),
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          onSubmitted: (val) {
                            final num = int.tryParse(val.replaceAll(',', '')) ?? 0;
                            if (num != widget.goalExpense) {
                              widget.onGoalExpenseChanged(num);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("목표 지출이 ${num.toString()}원으로 저장되었습니다.")),
                              );
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text('원', style: TextStyle(fontSize: 15, color: brown, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () {
                        final num = int.tryParse(goalCtrl.text.replaceAll(',', '')) ?? 0;
                        if (num != widget.goalExpense) {
                          widget.onGoalExpenseChanged(num);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("목표 지출이 ${num.toString()}원으로 저장되었습니다.")),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange,
                        minimumSize: const Size(48, 40),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        elevation: 0,
                      ),
                      child: const Text("저장", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.deepOrange.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '현재 목표 : ${widget.goalExpense.toString()} 원',
                    style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                        color: Colors.deepOrange),
                  ),
                ),
              ],
            ),
          ),
          _SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionLabel(label: '기타 설정', color: brown),
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.red, size: 28),
                  title: const Text('전체 기록 삭제',
                      style: TextStyle(fontSize: 16, color: Colors.red, fontWeight: FontWeight.bold)),
                  onTap: () async {
                    await showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('전체 메모 및 지출 기록 삭제'),
                        content: const Text('정말 모든 메모 및 수입, 지출 기록을 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(),
                            child: const Text('취소'),
                          ),
                          TextButton(
                            onPressed: () {
                              widget.onResetData();
                              Navigator.of(ctx).pop();
                            },
                            child: const Text('삭제', style: TextStyle(color: Colors.red)),
                          ),
                        ],
                      ),
                    );
                  },
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.redAccent),
                  contentPadding: const EdgeInsets.only(left: 8, right: 8, top: 0, bottom: 0),
                ),
                ListTile(
                  leading: const Icon(Icons.help_outline_rounded, color: Colors.teal, size: 26),
                  title: const Text('도움말',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const HelpPage()),
                    );
                  },
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  contentPadding: const EdgeInsets.only(left: 8, right: 8, top: 0, bottom: 0),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Center(
            child: Text(
              '버전 1.0.0',
              style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                  letterSpacing: 1,
                  fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final Widget child;
  const _SectionCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      elevation: 4,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      shadowColor: Colors.brown.withOpacity(0.08),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
        child: child,
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  final Color color;
  const _SectionLabel({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 16,
          color: color,
          letterSpacing: 0.5),
    );
  }
}
