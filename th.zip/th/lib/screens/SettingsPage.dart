import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  final bool isDarkMode;
  final Function(bool) onThemeChanged;
  final double fontSize;
  final Function(double) onFontSizeChanged;
  final VoidCallback onResetData;

  // 목표 지출 금액과 변경 콜백 추가
  final int goalExpense;
  final Function(int) onGoalExpenseChanged;

  const SettingsPage({
    Key? key,
    required this.isDarkMode,
    required this.onThemeChanged,
    required this.fontSize,
    required this.onFontSizeChanged,
    required this.onResetData,
    required this.goalExpense,
    required this.onGoalExpenseChanged,
  }) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late bool _isDarkMode;
  late double _fontSize;
  bool _notificationsEnabled = true;

  late int _goalExpense;

  @override
  void initState() {
    super.initState();
    _isDarkMode = widget.isDarkMode;
    _fontSize = widget.fontSize;
    _goalExpense = widget.goalExpense;
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('사용 도움말'),
        content: const Text(
          '앱 사용에 관한 팁과 도움말을 여기에 표시합니다.\n\n'
              '• 글자 크기는 슬라이더로 조절할 수 있습니다.\n'
              '• 다크 모드를 켜면 화면이 어두워집니다.\n'
              '• 알림 설정을 통해 중요한 소식을 받을 수 있습니다.\n'
              '• 데이터를 초기화하면 모든 메모와 지출 기록이 삭제됩니다.\n'
              '• 목표 지출을 설정하여, 지출이 목표를 초과할 경우 알림을 받을 수 있습니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('닫기'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('설정',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        children: [
          // 글자 크기 조절
          const Padding(
            padding: EdgeInsets.only(top: 16, bottom: 8),
            child: Text(
              '글자 크기 조절',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Slider(
            value: _fontSize,
            min: 12,
            max: 24,
            divisions: 6,
            label: '${_fontSize.toInt()} pt',
            onChanged: (value) {
              setState(() {
                _fontSize = value;
              });
              widget.onFontSizeChanged(value);
            },
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              '예시 텍스트: 예시 텍스트 입니다',
              style: TextStyle(fontSize: _fontSize),
            ),
          ),
          const Divider(),

          // 다크 모드 토글
          SwitchListTile(
            title: const Text('다크 모드'),
            value: _isDarkMode,
            onChanged: (bool value) {
              setState(() {
                _isDarkMode = value;
              });
              widget.onThemeChanged(value);
            },
            secondary: const Icon(Icons.dark_mode),
          ),
          const Divider(),

          // 알림 설정
          SwitchListTile(
            title: const Text('알림 받기'),
            value: _notificationsEnabled,
            onChanged: (val) {
              setState(() {
                _notificationsEnabled = val;
              });
              // TODO: 알림 기능 연동
            },
            secondary: const Icon(Icons.notifications_active),
          ),
          const Divider(),

          // 목표 지출 설정
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 8),
            child: Text(
              '목표 지출 설정',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.deepOrange[700],
              ),
            ),
          ),
          Slider(
            value: _goalExpense.toDouble(),
            min: 0,
            max: 3000000,
            divisions: 100,
            label: '${_goalExpense.toString()} 원',
            onChanged: (value) {
              setState(() {
                _goalExpense = value.toInt();
              });
              widget.onGoalExpenseChanged(_goalExpense);
            },
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              '현재 목표: $_goalExpense 원',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.deepOrange[900],
              ),
            ),
          ),
          const Divider(),

          // 도움말 버튼
          ListTile(
            leading: const Icon(Icons.help_outline, color: Colors.blue),
            title: const Text(
              '도움말',
              style: TextStyle(color: Colors.blue),
            ),
            onTap: _showHelpDialog,
          ),
          const Divider(),

          // 데이터 초기화
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.red),
            title: const Text(
              '모든 데이터 초기화',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('경고'),
                  content: const Text('모든 데이터가 삭제됩니다. 계속하시겠습니까?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('취소'),
                    ),
                    TextButton(
                      onPressed: () {
                        widget.onResetData();
                        Navigator.of(context).pop();
                      },
                      child: const Text(
                        '삭제',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),

          const SizedBox(height: 40),

          // 버전 표시
          const Center(
            child: Text(
              '버전 1.0.0',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
