import 'package:flutter/material.dart';

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});

  @override
  Widget build(BuildContext context) {
    final brown = const Color(0xFF6B4E16);
    return Scaffold(
      appBar: AppBar(
        title: const Text('도움말', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFFFFF8E7),
        foregroundColor: brown,
        elevation: 0,
      ),
      backgroundColor: const Color(0xFFFFF8E7),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            '앱 사용법 안내',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: brown,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            '- 홈: 오늘의 기록, 최근 다이어리, 지출을 빠르게 확인\n'
                '- 다이어리: 원하는 날짜를 선택해 일기를 남길 수 있습니다.\n'
                '- 지출: 수입/지출 내역을 등록, 카테고리별로 관리하세요.\n'
                '- 통계: 오늘/이번주/이번달/올해 기준으로 통계를 볼 수 있어요.\n'
                '- 설정: 목표 지출, 알림, 데이터 초기화 등을 관리합니다.\n',
            style: TextStyle(fontSize: 16, height: 1.5),
          ),
          const SizedBox(height: 30),
          Text(
            '자주 묻는 질문',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: brown,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 16),
          const _HelpQna(
            question: "Q. 데이터가 사라졌어요!",
            answer: "앱을 완전히 삭제하면 데이터가 모두 지워질 수 있습니다. 주기적으로 백업해 주세요.",
          ),
          const _HelpQna(
            question: "Q. 목표 지출을 바꿨는데 통계에 안 나와요.",
            answer: "목표 지출은 변경 즉시 저장됩니다. 통계는 등록된 내역에 따라 실시간 반영됩니다.",
          ),
          const _HelpQna(
            question: "Q. 내 데이터는 어디 저장돼요?",
            answer: "모든 데이터는 이 기기 내부에 안전하게 저장됩니다.",
          ),
          const SizedBox(height: 30),
          Center(
            child: Text(
              "기타 문의: ryus13975@naver.com",
              style: TextStyle(color: brown, fontSize: 15, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpQna extends StatelessWidget {
  final String question;
  final String answer;
  const _HelpQna({required this.question, required this.answer});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(question, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.teal)),
          const SizedBox(height: 4),
          Text(answer, style: const TextStyle(fontSize: 15)),
        ],
      ),
    );
  }
}
