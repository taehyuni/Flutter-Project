import 'package:flutter/material.dart';

class ExpensePage extends StatelessWidget {
  const ExpensePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '✍️ 오늘은 어떤 하루였나요?',
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}
