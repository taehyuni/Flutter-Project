import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class StatsPage extends StatefulWidget {
  const StatsPage({super.key});

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  String _sortBy = '날짜'; // or '금액'

  // 예시 지출 데이터 (날짜별로 Map 구성)
  final Map<DateTime, List<Map<String, dynamic>>> _expenseData = {
    DateTime(2025, 5, 27): [],
    DateTime(2025, 5, 28): [
      {'text': '점심', 'amount': 10000},
      {'text': '커피', 'amount': 4000},
    ],
    DateTime(2025, 5, 29): [
      {'text': '저녁식사', 'amount': 15000},
    ],
  };

  @override
  Widget build(BuildContext context) {
    List<DateTime> sortedDates = _expenseData.keys.toList();

    if (_sortBy == '날짜') {
      sortedDates.sort((a, b) => b.compareTo(a)); // 최근 날짜 먼저
    } else if (_sortBy == '금액') {
      sortedDates.sort((a, b) {
        int totalA = _expenseData[a]?.fold<int>(
            0, (sum, item) => sum + (item['amount'] as int? ?? 0)) ?? 0;

        int totalB = _expenseData[b]?.fold<int>(
            0, (sum, item) => sum + (item['amount'] as int? ?? 0)) ?? 0;

        return totalB.compareTo(totalA); // 많은 금액 먼저
      });
    }

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
          title: const Text('통계',
          style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          ),
          ),
          centerTitle: true,
        backgroundColor: const Color(0xFFFFF8E7),
        actions: [
          DropdownButton<String>(
            value: _sortBy,
            items: const [
              DropdownMenuItem(value: '날짜', child: Text('날짜순')),
              DropdownMenuItem(value: '금액', child: Text('금액순')),
            ],
            onChanged: (value) {
              if (value != null) {
                setState(() {
                  _sortBy = value;
                });
              }
            },
            dropdownColor: Colors.white,
            underline: const SizedBox(),
            icon: const Icon(Icons.sort),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: sortedDates.length,
        itemBuilder: (context, index) {
          final date = sortedDates[index];
          final entries = _expenseData[date]!;
          final formattedDate = DateFormat('yyyy년 MM월 dd일').format(date);

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  formattedDate,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF6B4E16),
                  ),
                ),
                const SizedBox(height: 4),
                if (entries.isEmpty)
                  const Text(
                    '지출이 없습니다',
                    style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                  )
                else
                  ...entries.map((e) => Text(
                    '${e['text']} + ${NumberFormat('#,###').format(e['amount'])}원',
                    style: const TextStyle(fontSize: 16),
                  )),
                const Divider(thickness: 1),
              ],
            ),
          );
        },
      ),
    );
  }
}
