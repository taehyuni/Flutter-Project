import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/memo.dart';

class DiaryPage extends StatefulWidget {
  const DiaryPage({super.key});

  @override
  State<DiaryPage> createState() => _DiaryPageState();
}

class _DiaryPageState extends State<DiaryPage> {
  late Box<Memo> _memoBox;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _memoBox = Hive.box<Memo>('memos');
  }

  DateTime _getDateKey(DateTime date) => DateTime.utc(date.year, date.month, date.day);

  List<Memo> _getMemosForDay(DateTime day) =>
      _memoBox.values.where((m) => _getDateKey(m.date) == _getDateKey(day)).toList();

  Future<void> _addMemo(DateTime date, String content) async {
    await _memoBox.add(Memo(date: date, content: content));
    setState(() {});
  }

  Future<void> _removeMemo(Memo memo) async {
    await memo.delete();
    setState(() {});
  }

  void _showMemoDialog(DateTime date) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: const Color(0xFFFFFAF3),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 400),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    '${date.year}년 ${date.month}월 ${date.day}일',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF6B4E16)),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: controller,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: '메모를 입력하세요',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFBFA87C),
                        width: 1.0,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B4E16),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () async {
                        final text = controller.text.trim();
                        if (text.isNotEmpty) {
                          await _addMemo(date, text);
                        }
                        Navigator.of(context).pop();
                      },
                      child: const Text('저장'),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('취소', style: TextStyle(color: Colors.grey)),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _buildStyledButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF6B4E16),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 1,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 13)),
    );
  }

  Widget _buildMemoCard(Memo memo) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: const Color(0xFFFFFAF3),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        title: Text(memo.content),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.redAccent),
          onPressed: () => _removeMemo(memo),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final memoList = _selectedDay != null ? _getMemosForDay(_selectedDay!) : [];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        toolbarHeight: 0,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          TableCalendar(
            focusedDay: _focusedDay,
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            rowHeight: 60,
            selectedDayPredicate: (d) => _selectedDay != null && isSameDay(d, _selectedDay),
            onDaySelected: (sel, foc) {
              setState(() {
                _selectedDay = sel;
                _focusedDay = foc;
              });
            },
            eventLoader: _getMemosForDay,
            calendarStyle: const CalendarStyle(
              markersMaxCount: 0,
              todayDecoration: BoxDecoration(color: Color(0xFFE6D3B3), shape: BoxShape.circle),
              selectedDecoration: BoxDecoration(color: Color(0xFF6B4E16), shape: BoxShape.circle),
              selectedTextStyle: TextStyle(color: Colors.white),
            ),
            headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (ctx, day, _) {
                final memos = _getMemosForDay(day);
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('${day.day}', style: const TextStyle(fontSize: 14)),
                    if (memos.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 2.0),
                        child: Text(
                          memos.first.content.length > 10
                              ? '${memos.first.content.substring(0, 10)}...'
                              : memos.first.content,
                          style: const TextStyle(fontSize: 10, color: Colors.brown),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          if (_selectedDay != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Text(
                    '${_selectedDay!.year}년 ${_selectedDay!.month}월 ${_selectedDay!.day}일 메모',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  _buildStyledButton('메모 추가', () => _showMemoDialog(_selectedDay!)),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: _selectedDay == null || memoList.isEmpty
                ? const Center(
              child: Text(
                '날짜를 선택해주세요.',
                style: TextStyle(color: Colors.grey),
              ),
            )
                : ListView.builder(
              itemCount: memoList.length,
              itemBuilder: (_, i) => _buildMemoCard(memoList[i]),
            ),
          ),
        ],
      ),
    );
  }
}
