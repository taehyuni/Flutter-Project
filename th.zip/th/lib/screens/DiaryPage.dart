import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class DiaryPage extends StatefulWidget {
  const DiaryPage({super.key});

  @override
  State<DiaryPage> createState() => _DiaryPageState();
}

class _DiaryPageState extends State<DiaryPage> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  final Map<DateTime, List<String>> _memos = {};

  // UTC 날짜로 통일해서 Map 키로 사용하기 위한 헬퍼
  DateTime _getDateKey(DateTime date) {
    return DateTime.utc(date.year, date.month, date.day);
  }

  List<String> _getMemosForDay(DateTime day) {
    return _memos[_getDateKey(day)] ?? [];
  }

  void _addMemo(DateTime date, String memo) {
    final key = _getDateKey(date);
    if (!_memos.containsKey(key)) {
      _memos[key] = [];
    }
    _memos[key]!.add(memo);
  }

  void _removeMemo(DateTime date, String memo) {
    final key = _getDateKey(date);
    _memos[key]?.remove(memo);
    if (_memos[key]?.isEmpty ?? false) {
      _memos.remove(key);
    }
  }

  void _showMemoDialog(DateTime date) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${date.year}년 ${date.month}월 ${date.day}일 메모 추가'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: '메모 입력'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              final text = controller.text.trim();
              if (text.isNotEmpty) {
                setState(() {
                  _addMemo(date, text);
                });
              }
              Navigator.of(context).pop();
            },
            child: const Text('저장'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('취소'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final memos = _selectedDay != null ? _getMemosForDay(_selectedDay!) : [];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Text(
            '다이어리',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        TableCalendar(
          focusedDay: _focusedDay,
          firstDay: DateTime(2000),
          lastDay: DateTime(2100),
          selectedDayPredicate: (day) =>
          _selectedDay != null && isSameDay(day, _selectedDay),
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDay = selectedDay;
              _focusedDay = focusedDay;
            });
          },
          eventLoader: _getMemosForDay,
          calendarStyle: const CalendarStyle(
            markersMaxCount: 0,
          ),
          headerStyle: const HeaderStyle(
            formatButtonVisible: false,
          ),
          calendarBuilders: CalendarBuilders(
            defaultBuilder: (context, day, focusedDay) {
              final dayMemos = _getMemosForDay(day);
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('${day.day}'),
                  if (dayMemos.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 2.0),
                      child: Text(
                        dayMemos.first,
                        style: const TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                ],
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        if (_selectedDay != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Text(
                  '${_selectedDay!.year}년 ${_selectedDay!.month}월 ${_selectedDay!.day}일 메모',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                ElevatedButton(
                  onPressed: () => _showMemoDialog(_selectedDay!),
                  child: const Text('메모 추가'),
                ),
              ],
            ),
          ),
        const SizedBox(height: 8),
        if (_selectedDay != null)
          memos.isEmpty
              ? const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text('메모가 없습니다.', style: TextStyle(color: Colors.grey)),
          )
              : Expanded(
            child: ListView(
              children: memos.map((memo) => ListTile(
                title: Text(memo),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      _removeMemo(_selectedDay!, memo);
                    });
                  },
                ),
              )).toList(),
            ),
          ),
      ],
    );
  }
}
