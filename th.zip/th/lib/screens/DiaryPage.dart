import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/memo.dart';

class DiaryPage extends StatefulWidget {
  const DiaryPage({super.key});

  @override
  State<DiaryPage> createState() => _DiaryPageState();
}

class _DiaryPageState extends State<DiaryPage> {
  late Box<Memo> _memoBox;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _memoBox = Hive.box<Memo>('memos');
  }

  DateTime _getDateKey(DateTime date) => DateTime.utc(date.year, date.month, date.day);

  List<Memo> _getMemosForDay(DateTime day) {
    final key = _getDateKey(day);
    return _memoBox.values.where((memo) => _getDateKey(memo.date) == key).toList();
  }

  Future<void> _addMemo(DateTime date, String content) async {
    final memo = Memo(date: date, content: content);
    await _memoBox.add(memo);
    if (mounted) setState(() {});
  }

  void _removeMemo(Memo memo) async {
    await memo.delete();
    if (mounted) setState(() {});
  }

  void _showMemoDialog(DateTime date) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${date.year}년 ${date.month}월 ${date.day}일 메모 추가'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: '메모 입력'),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final text = controller.text.trim();
              if (text.isNotEmpty) {
                await _addMemo(date, text);
              }
              Navigator.of(context).pop();
            },
            child: const Text('저장'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('취소'),
          ),
        ],
      ),
    );
  }

  Widget _buildStyledButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF6B4E16),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 1,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      child: Text(label),
    );
  }

  Widget _buildMemoCard(Memo memo) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: const Color(0xFFFFFAF3),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        title: Text(memo.content),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.redAccent),
          onPressed: () => _removeMemo(memo),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final memoList = _selectedDay != null ? _getMemosForDay(_selectedDay!) : [];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        toolbarHeight: 0,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          TableCalendar(
            focusedDay: _focusedDay,
            rowHeight: 60,
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            selectedDayPredicate: (day) => _selectedDay != null && isSameDay(day, _selectedDay),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            eventLoader: (day) => _getMemosForDay(day),
            calendarStyle: const CalendarStyle(
              markersMaxCount: 0,
              todayDecoration: BoxDecoration(color: Color(0xFFE6D3B3), shape: BoxShape.circle),
              selectedDecoration: BoxDecoration(color: Color(0xFF6B4E16), shape: BoxShape.circle),
              selectedTextStyle: TextStyle(color: Colors.white),
            ),
            headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
            calendarBuilders: CalendarBuilders(
              defaultBuilder: (context, day, _) {
                final memos = _getMemosForDay(day);
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('${day.day}', style: const TextStyle(fontSize: 14)),
                    if (memos.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 2.0),
                        child: Text(
                          memos.first.content.length > 10
                              ? '${memos.first.content.substring(0, 10)}...'
                              : memos.first.content,
                          style: const TextStyle(fontSize: 10, color: Colors.brown),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          if (_selectedDay != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Text(
                    '${_selectedDay!.year}년 ${_selectedDay!.month}월 ${_selectedDay!.day}일 메모',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  _buildStyledButton('메모 추가', () => _showMemoDialog(_selectedDay!)),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: _selectedDay == null
                ? const Center(
              child: Text(
                '요일을 선택해주세요.',
                style: TextStyle(color: Colors.grey),
              ),
            )
                : memoList.isEmpty
                ? const Center(
              child: Text(
                '메모가 없습니다.',
                style: TextStyle(color: Colors.grey),
              ),
            )
                : ListView.builder(
              itemCount: memoList.length,
              itemBuilder: (_, i) => _buildMemoCard(memoList[i]),
            ),
          ),
        ],
      ),
    );
  }
}
