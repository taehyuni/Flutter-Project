import 'package:hive/hive.dart';

part 'memo.g.dart';

@HiveType(typeId: 0)
class Memo extends HiveObject {
  @HiveField(0)
  late DateTime date;

  @HiveField(1)
  late String content;

  Memo({required this.date, required this.content});
}
