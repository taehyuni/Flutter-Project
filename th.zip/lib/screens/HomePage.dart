// HomePage.dart (최종 통합본)

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/memo.dart';
import '../models/expense.dart';
import 'DiaryPage.dart';
import 'ExpensePage.dart';
import 'StatsPage.dart';
import 'SettingsPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Box<Memo> _memoBox;
  late Box<Expense> _expenseBox;

  DateTime today = DateTime.now();
  int _selectedIndex = 0;

  // 상태 관리용
  bool isDarkMode = false;
  double fontSize = 16;
  int goalExpense = 500000;

  @override
  void initState() {
    super.initState();
    _memoBox = Hive.box<Memo>('memos');
    _expenseBox = Hive.box<Expense>('expenses');
  }

  DateTime _getDateKey(DateTime date) => DateTime.utc(date.year, date.month, date.day);

  List<Memo> _getTodayMemos() => _memoBox.values.where((m) => _getDateKey(m.date) == _getDateKey(today)).toList();

  List<Expense> _getTodayExpenses() => _expenseBox.values.where((e) => _getDateKey(e.date) == _getDateKey(today) && e.type == '지출').toList();

  List<Expense> _getTodayIncomes() => _expenseBox.values.where((e) => _getDateKey(e.date) == _getDateKey(today) && e.type == '수입').toList();

  List<Expense> _getRecentExpenses() {
    final todayKey = _getDateKey(today);
    final recentDate = _expenseBox.values
        .where((e) => e.type == '지출' && _getDateKey(e.date).isBefore(todayKey))
        .map((e) => _getDateKey(e.date))
        .toSet()
        .fold<DateTime?>(null, (prev, d) => prev == null || d.isAfter(prev) ? d : prev);

    if (recentDate == null) return [];
    return _expenseBox.values.where((e) => _getDateKey(e.date) == recentDate && e.type == '지출').toList();
  }

  List<Expense> _getRecentIncomes() {
    final todayKey = _getDateKey(today);
    final recentDate = _expenseBox.values
        .where((e) => e.type == '수입' && _getDateKey(e.date).isBefore(todayKey))
        .map((e) => _getDateKey(e.date))
        .toSet()
        .fold<DateTime?>(null, (prev, d) => prev == null || d.isAfter(prev) ? d : prev);

    if (recentDate == null) return [];
    return _expenseBox.values.where((e) => _getDateKey(e.date) == recentDate && e.type == '수입').toList();
  }

  // 📌 이번달 지출 총합
  int _getThisMonthTotalExpense() {
    final firstDay = DateTime(today.year, today.month, 1);
    return _expenseBox.values
        .where((e) => e.type == '지출' && e.date.isAfter(firstDay.subtract(const Duration(days: 1))) && e.date.isBefore(today.add(const Duration(days: 1))))
        .fold(0, (sum, e) => sum + e.amount);
  }

  // 📌 이번달 수입 총합
  int _getThisMonthTotalIncome() {
    final firstDay = DateTime(today.year, today.month, 1);
    return _expenseBox.values
        .where((e) => e.type == '수입' && e.date.isAfter(firstDay.subtract(const Duration(days: 1))) && e.date.isBefore(today.add(const Duration(days: 1))))
        .fold(0, (sum, e) => sum + e.amount);
  }

  void _resetData() async {
    await _memoBox.clear();
    await _expenseBox.clear();
    if (mounted) setState(() {});
  }

  void _addMemo() async {
    TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('오늘의 메모 추가'),
        content: TextField(controller: controller, decoration: const InputDecoration(labelText: '메모 입력')),
        actions: [
          TextButton(onPressed: () async {
            final text = controller.text.trim();
            if (text.isNotEmpty) {
              await _memoBox.add(Memo(date: today, content: text));
              setState(() {});
            }
            Navigator.pop(context);
          }, child: const Text('저장')),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
        ],
      ),
    );
  }

  void _addExpense({required bool isIncome}) {
    TextEditingController detailController = TextEditingController();
    TextEditingController amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(isIncome ? '오늘의 수입 추가' : '오늘의 지출 추가'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: detailController, decoration: const InputDecoration(labelText: '내역')),
            TextField(controller: amountController, decoration: const InputDecoration(labelText: '금액'), keyboardType: TextInputType.number),
          ],
        ),
        actions: [
          TextButton(onPressed: () async {
            final detail = detailController.text.trim();
            final amount = int.tryParse(amountController.text.trim());
            if (detail.isNotEmpty && amount != null && amount > 0) {
              await _expenseBox.add(Expense(
                date: today,
                type: isIncome ? '수입' : '지출',
                category: '일반',
                detail: detail,
                amount: amount,
                timestamp: DateTime.now(),
              ));
              setState(() {});
            }
            Navigator.pop(context);
          }, child: const Text('저장')),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<String> items, VoidCallback? onAdd) {
    return Card(
      color: const Color(0xFFEFE6CF),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF6B4E16))),
              const Spacer(),
              if (onAdd != null)
                ElevatedButton(
                  onPressed: onAdd,
                  child: const Text('추가'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6B4E16),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                )
            ],
          ),
          const SizedBox(height: 8),
          items.isEmpty
              ? const Text('내역이 없습니다.', style: TextStyle(color: Colors.grey))
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: items.map((e) => Text(e, style: const TextStyle(fontSize: 16))).toList())
        ]),
      ),
    );
  }

  Widget _buildBody() {
    final formatter = NumberFormat('#,###');
    final memoItems = _getTodayMemos().map((e) => e.content).toList();
    final expenseItems = _getTodayExpenses().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final incomeItems = _getTodayIncomes().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final recentExpenses = _getRecentExpenses().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();
    final recentIncomes = _getRecentIncomes().map((e) => '${e.detail} - ${formatter.format(e.amount)}원').toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 5,
            color: Colors.white,
            shadowColor: Colors.brown.withOpacity(0.2),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('📓 오늘의 메모', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                      const Spacer(),
                      IconButton(
                        onPressed: _addMemo,
                        icon: const Icon(Icons.add_circle_outline, color: Color(0xFF5A3E1D)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  memoItems.isEmpty
                      ? const Text('메모가 없습니다.', style: TextStyle(color: Colors.grey))
                      : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: memoItems.map((e) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text('• $e', style: const TextStyle(fontSize: 15)),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(child: _buildBox('💸 오늘의 지출', expenseItems, () => _addExpense(isIncome: false))),
              const SizedBox(width: 12),
              Expanded(child: _buildBox('💰 오늘의 수입', incomeItems, () => _addExpense(isIncome: true))),
            ],
          ),

          const SizedBox(height: 16),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 4,
            color: Colors.white,
            shadowColor: Colors.brown.withOpacity(0.2),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('📅 이번달 요약', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: _buildSummary('총 지출', _getThisMonthTotalExpense(), Colors.red)),
                      const SizedBox(width: 12),
                      Expanded(child: _buildSummary('총 수입', _getThisMonthTotalIncome(), Colors.green)),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          if (recentExpenses.isNotEmpty)
            _buildBox('🧾 최근 지출', recentExpenses, null),
          if (recentIncomes.isNotEmpty)
            _buildBox('🧾 최근 수입', recentIncomes, null),
        ],
      ),
    );
  }

// 📌 카드 박스 구성 함수
  Widget _buildBox(String title, List<String> items, VoidCallback? onAdd) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.brown.withOpacity(0.2),
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF5A3E1D))),
                const Spacer(),
                if (onAdd != null)
                  IconButton(
                    onPressed: onAdd,
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF5A3E1D)),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            items.isEmpty
                ? const Text('내역이 없습니다.', style: TextStyle(color: Colors.grey))
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: items.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text('• $e', style: const TextStyle(fontSize: 15)),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

// 📌 요약 박스 구성 함수
  Widget _buildSummary(String title, int amount, Color color) {
    final formatter = NumberFormat('#,###');
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 14)),
          const SizedBox(height: 4),
          Text('${formatter.format(amount)}원', style: TextStyle(color: color, fontSize: 16)),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildBody(),
      const DiaryPage(),
      const ExpensePage(),
      const StatsPage(),
      SettingsPage(
        isDarkMode: isDarkMode,
        onThemeChanged: (val) => setState(() => isDarkMode = val),
        fontSize: fontSize,
        onFontSizeChanged: (val) => setState(() => fontSize = val),
        goalExpense: goalExpense,
        onGoalExpenseChanged: (val) => setState(() => goalExpense = val),
        onResetData: _resetData,
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFE6D3B3),
        title: Text(DateFormat('yyyy년 MM월 dd일').format(today), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        backgroundColor: const Color(0xFFF5F5DC),
        selectedItemColor: const Color(0xFF6B4E16),
        unselectedItemColor: Colors.brown[200],
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: '홈'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: '다이어리'),
          BottomNavigationBarItem(icon: Icon(Icons.attach_money), label: '지출'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: '통계'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: '설정'),
        ],
      ),
    );
  }
}
